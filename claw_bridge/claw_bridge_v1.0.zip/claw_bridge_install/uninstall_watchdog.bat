@echo off
REM === claw_bridge uninstall_watchdog.bat ===
REM 主人手双击 = 卸载计划任务 + 杀 watchdog 进程
REM 2026-06-07 11:15

setlocal enabledelayedexpansion
chcp 65001 >nul

set BASE_DIR=C:\coze-scheduler\claw_bridge
set LOG=%BASE_DIR%\uninstall.log
set TASKNAME=ClawBridgeWatchdog

echo === claw_bridge uninstall ===  >> %LOG%
echo [%date% %time%] START  >> %LOG%

REM === 1. 删计划任务 ===
schtasks /delete /tn "%TASKNAME%" /f >> %LOG% 2>&1
echo [%date% %time%] TASK_DELETED  >> %LOG%

REM === 2. 杀 watchdog 进程 ===
taskkill /IM pythonw.exe /FI "WINDOWTITLE eq claw_bridge*" /F >> %LOG% 2>&1
REM 直接按 PID_FILE 杀更稳
if exist "%BASE_DIR%\watchdog.pid" (
    set /p WATCHDOG_PID=<"%BASE_DIR%\watchdog.pid"
    echo [%date% %time%] KILL_PID %WATCHDOG_PID%  >> %LOG%
    taskkill /PID %WATCHDOG_PID% /F >> %LOG% 2>&1
)
echo [%date% %time%] PROCESS_KILLED  >> %LOG%

REM === 3. 删 lock + pid (保留 pending/result/done 留作记录) ===
if exist "%BASE_DIR%\watchdog.lock" del "%BASE_DIR%\watchdog.lock" >> %LOG% 2>&1
if exist "%BASE_DIR%\watchdog.pid" del "%BASE_DIR%\watchdog.pid" >> %LOG% 2>&1
echo [%date% %time%] CLEANED  >> %LOG%

echo.
echo ============================================
echo  claw_bridge watch dog 已卸载
echo ============================================
echo   计划任务 %TASKNAME% 已删
echo   watchdog 进程已杀
echo   log: %LOG%
echo ============================================
echo   注: pending/ result/ done/ 历史文件没删, 主人手清
echo ============================================
pause
endlocal
