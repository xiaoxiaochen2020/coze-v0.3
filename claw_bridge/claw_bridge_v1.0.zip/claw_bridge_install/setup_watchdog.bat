@echo off
REM === claw_bridge setup_watchdog.bat ===
REM 主人电脑手双击 1 次, 注册 Windows 计划任务 + 启 watchdog.py
REM 2026-06-07 11:15
REM
REM 用法: 双击本 BAT
REM 效果:
REM   1. 创建 C:\coze-scheduler\claw_bridge\ 目录结构
REM   2. 注册计划任务 ClawBridgeWatchdog (1 分钟跑一次 watchdog.py)
REM   3. 立即启一次 watchdog.py (主 Agent 端之后写 BAT 立即可跑)
REM   4. 写日志到 C:\coze-scheduler\claw_bridge\setup.log
REM
REM 注意:
REM   - 不用 admin (schtasks 当前用户 OK)
REM   - watchdog 跑超时 60s 自动杀
REM   - 计划任务 1 分钟一次保活 (watchdog 死掉自动重启)
REM   - 卸载跑 uninstall_watchdog.bat

setlocal enabledelayedexpansion
chcp 65001 >nul

set BASE_DIR=C:\coze-scheduler\claw_bridge
set PYTHON_EXE=C:\Python314\python.exe
set PYTHONW_EXE=C:\Python314\pythonw.exe
set WATCHDOG=%BASE_DIR%\watchdog.py
set LOG=%BASE_DIR%\setup.log
set TASKNAME=ClawBridgeWatchdog

echo === claw_bridge setup_watchdog.bat ===  >> %LOG%
echo [%date% %time%] START  >> %LOG%

REM === 1. 创目录 ===
if not exist "%BASE_DIR%" (
    mkdir "%BASE_DIR%" >> %LOG% 2>&1
)
if not exist "%BASE_DIR%\pending" mkdir "%BASE_DIR%\pending" >> %LOG% 2>&1
if not exist "%BASE_DIR%\result" mkdir "%BASE_DIR%\result" >> %LOG% 2>&1
if not exist "%BASE_DIR%\done" mkdir "%BASE_DIR%\done" >> %LOG% 2>&1
echo [%date% %time%] DIRS_READY  >> %LOG%

REM === 2. 验证 watchdog.py + python 存在 ===
if not exist "%WATCHDOG%" (
    echo [%date% %time%] FAIL watchdog.py NOT FOUND  >> %LOG%
    echo ERROR: watchdog.py 不存在, 请先由主 Agent 端 write_file
    pause
    exit /b 1
)
if not exist "%PYTHONW_EXE%" (
    echo [%date% %time%] WARN pythonw.exe not found, try python.exe  >> %LOG%
    set PYTHONW_EXE=%PYTHON_EXE%
)

REM === 3. 注册计划任务 (1 分钟跑一次, 不用 admin) ===
echo [%date% %time%] REGISTER_TASK  >> %LOG%
schtasks /delete /tn "%TASKNAME%" /f >nul 2>&1
schtasks /create ^
    /tn "%TASKNAME%" ^
    /tr "\"%PYTHONW_EXE%\" \"%WATCHDOG%\"" ^
    /sc minute ^
    /mo 1 ^
    /rl highest ^
    /f >> %LOG% 2>&1
if errorlevel 1 (
    echo [%date% %time%] FAIL schtasks create  >> %LOG%
    echo ERROR: 注册计划任务失败, 看 %LOG%
    pause
    exit /b 1
)
echo [%date% %time%] TASK_REGISTERED  >> %LOG%

REM === 4. 立即启一次 watchdog.py (主 Agent 端之后写 BAT 立即可跑, 不等 1 分钟) ===
echo [%date% %time%] START_WATCHDOG_NOW  >> %LOG%
start "" "%PYTHONW_EXE%" "%WATCHDOG%"
echo [%date% %time%] WATCHDOG_LAUNCHED  >> %LOG%

REM === 5. 显示结果 ===
echo.
echo ============================================
echo  claw_bridge watch dog 启好了
echo ============================================
echo   计划任务: %TASKNAME% (1 分钟跑一次)
echo   watchdog: %WATCHDOG%
echo   log:      %LOG%
echo   运行 log: %BASE_DIR%\watchdog.log
echo ============================================
echo   之后: 主 Agent 端 write_file 写 .bat 到:
echo         %BASE_DIR%\pending\
echo   watch dog 1 分钟内跑, 写结果到:
echo         %BASE_DIR%\result\
echo ============================================
echo.

REM === 6. 写一个测试 BAT 让主人验证 (立即跑) ===
echo @echo off > "%BASE_DIR%\pending\setup_self_test.bat"
echo echo === CLAW_BRIDGE_SETUP_SELF_TEST === >> "%BASE_DIR%\pending\setup_self_test.bat"
echo echo whoami=%%username%% >> "%BASE_DIR%\pending\setup_self_test.bat"
echo echo hostname=%%computername%% >> "%BASE_DIR%\pending\setup_self_test.bat"
echo echo date=%%date%% >> "%BASE_DIR%\pending\setup_self_test.bat"
echo echo time=%%time%% >> "%BASE_DIR%\pending\setup_self_test.bat"
echo echo python= >> "%BASE_DIR%\pending\setup_self_test.bat"
echo "%PYTHON_EXE%" --version >> "%BASE_DIR%\pending\setup_self_test.bat" 2>&1
echo echo === END === >> "%BASE_DIR%\pending\setup_self_test.bat"
echo [%date% %time%] SELF_TEST_BAT_WRITTEN  >> %LOG%

echo 看 %LOG% / %BASE_DIR%\watchdog.log 确认启动
echo 1 分钟内看 %BASE_DIR%\result\ 应有 setup_self_test_*.txt
echo.
pause
endlocal
