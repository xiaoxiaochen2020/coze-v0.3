# -*- coding: utf-8 -*-
"""
claw_bridge watchdog v1.0
主人电脑常驻 watch dog, 1 分钟轮询 pending\ 跑 .bat + 写 result\
- 主 Agent 端 write_file 写 .bat 到 C:\coze-scheduler\claw_bridge\pending\
- watch dog 1 分钟轮询, 跑 .bat (timeout 60s), 写 result\<name>_<ts>.txt
- watchdog 自己保活: vbs 套娃 + 计划任务双保活
- 2026-06-07 11:14 立 (主 Agent 端代劳方案 B 启动版)
"""
import os
import sys
import time
import subprocess
import shutil
import datetime
import traceback

# === 路径常量 (硬编码, 不读注册表/不读配置) ===
BASE_DIR = r"C:\coze-scheduler\claw_bridge"
PENDING_DIR = os.path.join(BASE_DIR, "pending")
RESULT_DIR = os.path.join(BASE_DIR, "result")
DONE_DIR = os.path.join(BASE_DIR, "done")
LOG_FILE = os.path.join(BASE_DIR, "watchdog.log")
LOCK_FILE = os.path.join(BASE_DIR, "watchdog.lock")
PID_FILE = os.path.join(BASE_DIR, "watchdog.pid")

# === 超时配置 ===
BAT_TIMEOUT_SEC = 60  # 单个 .bat 跑超时 60s
LOOP_INTERVAL_SEC = 60  # 1 分钟轮询
KEEP_ALIVE_INTERVAL_SEC = 30  # 30s 更新 lock 文件 mtime (保活探针)

# === 启动模式 ===
RUN_AS_WINDOW = True  # pythonw 启动不弹黑框

def log(msg):
    """写一行 log 到 LOG_FILE, 带时间戳"""
    ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = "[%s] %s\n" % (ts, msg)
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line)
    except Exception:
        pass
    if not RUN_AS_WINDOW:
        try:
            sys.stdout.write(line)
            sys.stdout.flush()
        except Exception:
            pass

def ensure_dirs():
    """确保 pending/result/done/log 目录存在"""
    for d in (BASE_DIR, PENDING_DIR, RESULT_DIR, DONE_DIR):
        try:
            if not os.path.isdir(d):
                os.makedirs(d)
        except Exception as e:
            log("MKDIR_FAIL %s: %s" % (d, e))

def is_already_running():
    """单实例: 检查 LOCK_FILE mtime < 90s 算活"""
    if not os.path.isfile(LOCK_FILE):
        return False
    try:
        mtime = os.path.getmtime(LOCK_FILE)
        age = time.time() - mtime
        return age < 90
    except Exception:
        return False

def touch_lock():
    """更新 LOCK_FILE mtime (保活)"""
    try:
        with open(LOCK_FILE, "w") as f:
            f.write(str(os.getpid()))
        # Windows 下需要再 touch 一下 mtime
        os.utime(LOCK_FILE, None)
    except Exception as e:
        log("TOUCH_LOCK_FAIL: %s" % e)

def run_one_bat(bat_path):
    """跑一个 .bat, 捕获 stdout+stderr, 写 result\<name>_<ts>.txt"""
    name = os.path.basename(bat_path)
    stem = os.path.splitext(name)[0]
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    result_path = os.path.join(RESULT_DIR, "%s_%s.txt" % (stem, ts))

    log("RUN_BAT start: %s" % name)
    try:
        proc = subprocess.run(
            [bat_path],
            capture_output=True,
            text=True,
            timeout=BAT_TIMEOUT_SEC,
            shell=False,
            cwd=BASE_DIR,
        )
        rc = proc.returncode
        out = proc.stdout or ""
        err = proc.stderr or ""
    except subprocess.TimeoutExpired:
        rc = -1
        out = ""
        err = "TIMEOUT_AFTER_%ds" % BAT_TIMEOUT_SEC
    except Exception as e:
        rc = -2
        out = ""
        err = "EXC: %s\n%s" % (e, traceback.format_exc())

    # 写结果
    try:
        with open(result_path, "w", encoding="utf-8") as f:
            f.write("=== CLAW_BRIDGE_RESULT ===\n")
            f.write("BAT_NAME: %s\n" % name)
            f.write("RUN_TS: %s\n" % ts)
            f.write("RETURN_CODE: %d\n" % rc)
            f.write("=== STDOUT ===\n")
            f.write(out)
            f.write("\n=== STDERR ===\n")
            f.write(err)
            f.write("\n=== END ===\n")
    except Exception as e:
        log("WRITE_RESULT_FAIL: %s" % e)

    # 移走 .bat 到 done\
    try:
        done_path = os.path.join(DONE_DIR, name)
        if os.path.isfile(done_path):
            os.remove(done_path)
        shutil.move(bat_path, done_path)
    except Exception as e:
        log("MOVE_DONE_FAIL: %s" % e)

    log("RUN_BAT done: %s rc=%d" % (name, rc))

def scan_pending():
    """扫 pending\ 跑 .bat, 按 mtime 排序"""
    if not os.path.isdir(PENDING_DIR):
        return
    try:
        bats = []
        for fn in os.listdir(PENDING_DIR):
            if fn.lower().endswith((".bat", ".cmd")):
                fp = os.path.join(PENDING_DIR, fn)
                bats.append((os.path.getmtime(fp), fp))
        bats.sort()
        for _, fp in bats:
            run_one_bat(fp)
    except Exception as e:
        log("SCAN_PENDING_FAIL: %s" % e)

def write_pid():
    """写 PID_FILE"""
    try:
        with open(PID_FILE, "w") as f:
            f.write(str(os.getpid()))
    except Exception as e:
        log("WRITE_PID_FAIL: %s" % e)

def main():
    ensure_dirs()
    if is_already_running():
        log("ALREADY_RUNNING exit")
        return
    touch_lock()
    write_pid()
    log("WATCHDOG_START pid=%d" % os.getpid())

    last_keepalive = 0
    last_scan = 0
    while True:
        try:
            now = time.time()
            if now - last_keepalive >= KEEP_ALIVE_INTERVAL_SEC:
                touch_lock()
                last_keepalive = now
            if now - last_scan >= LOOP_INTERVAL_SEC:
                scan_pending()
                last_scan = now
        except Exception as e:
            log("LOOP_EXC: %s" % e)
        time.sleep(5)

if __name__ == "__main__":
    main()
