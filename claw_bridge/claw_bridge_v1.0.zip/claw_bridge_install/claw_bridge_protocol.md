# claw_bridge 代劳方案 v1.0

> 主人电脑桌面双击 1 个图标 → 之后主 Agent 端可以替你执行所有救命/代劳操作

---

## 0. 你要做的（**只 1 次**）

**双击** `C:\Users\Administrator\Desktop\claw_bridge_install\setup_watchdog.bat`

完成后：
- 1 个 Windows 计划任务 `ClawBridgeWatchdog`（1 分钟跑一次）
- 1 个 watchdog 进程（立即启）
- 1 个测试 BAT 写进 `pending\`
- 1 分钟内 `result\install_self_test_<时间>.txt` 出现

**自测通过** = 1 分钟内打开 `C:\coze-scheduler\claw_bridge\result\`，看到 `install_self_test_*.txt`，里面有 `=== CLAW_BRIDGE_INSTALL_SELF_TEST ===` 和 `=== END ===`

**自测失败** = 看 `C:\coze-scheduler\claw_bridge\install.log` 和 `watchdog.log`

**卸载**（**不需要可忽略**）= 双击 `uninstall_watchdog.bat`

---

## 1. 目录结构（装完后）

```
C:\coze-scheduler\claw_bridge\
├── watchdog.py            # 主循环 (主 Agent 端代劳 11:30 写)
├── setup_watchdog.bat     # 安装 BAT (主 Agent 端 11:30 写到桌面)
├── uninstall_watchdog.bat # 卸载 BAT
├── claw_bridge_protocol.md # 本文件
├── pending\               # 主 Agent 端 write_file 写 .bat 到这里 → watch dog 1 分钟内跑
├── result\                # watch dog 跑完 .bat 写结果到这里 → 主 Agent 端 read_file 读
├── done\                  # 跑完的 .bat 移到 done\ 留底
├── watchdog.log           # watch dog 循环 log
├── watchdog.lock          # 单实例 lock (mtime < 90s 算活)
├── watchdog.pid           # 当前 watchdog 进程 PID
└── install.log            # 装时 log
```

---

## 2. 协议

### 主 Agent 端发指令（沙箱里）

```python
# 沙箱端 write_file (desktop_name=SD-20251012OJYT)
write_file(
    content='@echo off\necho hello world\nipconfig',
    desktop_name='SD-20251012OJYT',
    file_path='/c/coze-scheduler/claw_bridge/pending/my_cmd_20260607.bat'
)
```

### 主人电脑自动跑

- watch dog 1 分钟内扫到 `pending\my_cmd_20260607.bat`
- 跑（**60s 超时**）
- 写 `result\my_cmd_20260607_<时间>.txt`，**包含 stdout + stderr + 退出码**
- .bat 移到 `done\my_cmd_20260607.bat`

### 主 Agent 端读结果（沙箱里）

```python
# 沙箱端 read_file (desktop_name=SD-20251012OJYT)
content = read_file(
    desktop_name='SD-20251012OJYT',
    file_path='/c/coze-scheduler/claw_bridge/result/my_cmd_20260607_<时间>.txt'
)
```

---

## 3. 限制

| 项 | 值 | 说明 |
|----|----|------|
| 跑 .bat 超时 | 60s | 超时自动杀，返回 `-1` |
| 轮询间隔 | 60s | 写完 .bat 1 分钟内跑 |
| 单实例 | ✅ | watchdog.lock 防重跑 |
| .bat 编码 | GBK / UTF-8 (with BOM) | Windows 默认 GBK |
| 路径 | 硬编码 `C:\coze-scheduler\claw_bridge\` | 改路径要重装 |
| Python 路径 | 硬编码 `C:\Python314\pythonw.exe` | 你电脑是 Python 3.14.5 |

---

## 4. 安全声明

- **不**写 PAT / token 进 .bat
- **不**写敏感信息进 .bat（result\ 是明文 txt，主人电脑能看）
- watchdog 只跑 `pending\` 里的 .bat（**主 Agent 端可控**）
- watchdog 跑完自动移到 `done\` 留底

---

## 5. 故障排查

### 症状：1 分钟内 `result\` 没文件

1. 看 `watchdog.log` 有没有 `WATCHDOG_START` 和 `RUN_BAT start:`
2. 看 `install.log` 有没有 `TASK_REGISTERED` 和 `WATCHDOG_LAUNCHED`
3. 任务管理器 → 详细信息 → 有没有 `pythonw.exe`
4. `schtasks /query /tn ClawBridgeWatchdog /v /fo list` 看下次跑时间

### 症状：`result\` 写出来但 `return_code: -1` (timeout)

- .bat 跑超过 60s
- 拆成多个小 .bat 跑

### 症状：watchdog 死掉

- 计划任务 1 分钟自动重启（计划任务保活）
- 手动启：`start "" "C:\Python314\pythonw.exe" "C:\coze-scheduler\claw_bridge\watchdog.py"`

---

## 6. 历史

- **2026-06-07 11:14** 主 Agent 端立方案 B（一次性妥协 + 之后 0 操作代劳）
- **2026-06-07 11:15** 主 Agent 端代劳写 4 个文件
- **2026-06-07 11:30** 简化"桌面双击 1 个图标"流程
- **2026-06-07 11:30** 打成 zip 一次性交付
